package guia3_empresa;

import java.util.Arrays;
import java.util.HashMap;

public class Bonificacion {

    private int[] arraySueldo;
    private int[] sueldosMasBajos;
    
    private HashMap<Integer, EmpleadoVO> empleadosBeneficiados;

    public Bonificacion(int[] arraySueldo, int[] sueldosMasBajos, HashMap<Integer, EmpleadoVO> empleadosBeneficiados) {
        this.arraySueldo = arraySueldo;
        this.sueldosMasBajos = sueldosMasBajos;
        this.empleadosBeneficiados = empleadosBeneficiados;
    }

    

    public Bonificacion() {
        this.arraySueldo = new int[0];
        this.sueldosMasBajos = new int[30];
        this.empleadosBeneficiados = new HashMap<>();        
       
        

    }

 
    public HashMap<Integer, EmpleadoVO> getEmpleadosBeneficiados() {
        return empleadosBeneficiados;
    }

    public void setEmpleadosBeneficiados(HashMap<Integer, EmpleadoVO> empleadosBeneficiados) {
        this.empleadosBeneficiados = empleadosBeneficiados;
    }

    public int[] getArraySueldo() {
        return arraySueldo;
    }

    public void setArraySueldo(int[] arraySueldo) {
        this.arraySueldo = arraySueldo;
    }

    public int[] getSueldosMasBajos() {
        return sueldosMasBajos;
    }

    public void setSueldosMasBajos(int[] sueldosMasBajos) {
        this.sueldosMasBajos = sueldosMasBajos;
    }

    public void QuickSort(int[] arreglo, int inicio, int fin) {
        if (inicio < fin) {
            // Particionamos el arreglo y obtenemos el índice del pivote
            int indicePivote = particion(arreglo, inicio, fin);

            // Ordenamos recursivamente los subarreglos antes y después del pivote
            QuickSort(arreglo, inicio, indicePivote - 1);
            QuickSort(arreglo, indicePivote + 1, fin);
        }
    }

    public int particion(int[] arreglo, int inicio, int fin) {
        int pivote = arreglo[fin]; // Tomamos el último elemento como pivote
        int i = inicio - 1; // Índice del elemento más pequeño

        for (int j = inicio; j < fin; j++) {
            // Si el elemento actual es menor o igual al pivote
            if (arreglo[j] <= pivote) {
                i++;

                // Intercambiamos arr[i] y arr[j]
                int temp = arreglo[i];
                arreglo[i] = arreglo[j];
                arreglo[j] = temp;
            }
        }

        // Intercambiamos arr[i+1] y arr[fin] (pivote)
        int temp = arreglo[i + 1];
        arreglo[i + 1] = arreglo[fin];
        arreglo[fin] = temp;

        return i + 1;
    }

    public void SueldosMasBajos(EmpleadoDAO empleadoDAO) {
        QuickSort(arraySueldo, 0, arraySueldo.length - 1);
         
        
        for (int i = 0; i < 30; i++) {
            sueldosMasBajos[i]=arraySueldo[i];
        }
        
        
        
        for (int i = 0; i < 100; i++) {
            for (int j = 0; j < 30; j++) {
                 EmpleadoVO empleadoVO = empleadoDAO.getInfoEmpleados().get(i);
            if (empleadoVO.getSueldoEmpleado() == sueldosMasBajos[j]) {
                empleadosBeneficiados.put(i, empleadoVO);
                
            }
            
            }
          
        }
        
        

        
        
        System.out.println(empleadosBeneficiados.size());
        
        
    }

}
