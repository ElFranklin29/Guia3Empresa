/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guia3_empresa;
public class Main {
    public static void main(String[] args) {
        int[] arreglo = {5, 3, 8, 4, 2, 7, 1, 6};
        
        System.out.println("Arreglo original:");
        imprimirArreglo(arreglo);
        
        // Llamada al método QuickSort para ordenar el arreglo
        quickSort(arreglo, 0, arreglo.length - 1);
        
        System.out.println("Arreglo ordenado:");
        imprimirArreglo(arreglo);
    }
    
    // Método para imprimir un arreglo
    public static void imprimirArreglo(int[] arreglo) {
        for (int i = 0; i < arreglo.length; i++) {
            System.out.print(arreglo[i] + " ");
        }
        System.out.println();
    }

    // Implementación del algoritmo QuickSort
    public static void quickSort(int[] arreglo, int inicio, int fin) {
        if (inicio < fin) {
            // Particionamos el arreglo y obtenemos el índice del pivote
            int indicePivote = particion(arreglo, inicio, fin);

            // Ordenamos recursivamente los subarreglos antes y después del pivote
            quickSort(arreglo, inicio, indicePivote - 1);
            quickSort(arreglo, indicePivote + 1, fin);
        }
    }

    // Método para particionar el arreglo y retornar el índice del pivote
    public static int particion(int[] arreglo, int inicio, int fin) {
        int pivote = arreglo[fin]; // Tomamos el último elemento como pivote
        int i = inicio - 1; // Índice del elemento más pequeño

        for (int j = inicio; j < fin; j++) {
            // Si el elemento actual es menor o igual al pivote
            if (arreglo[j] <= pivote) {
                i++;

                // Intercambiamos arr[i] y arr[j]
                int temp = arreglo[i];
                arreglo[i] = arreglo[j];
                arreglo[j] = temp;
            }
        }

        // Intercambiamos arr[i+1] y arr[fin] (pivote)
        int temp = arreglo[i + 1];
        arreglo[i + 1] = arreglo[fin];
        arreglo[fin] = temp;

        return i + 1;
    }
}